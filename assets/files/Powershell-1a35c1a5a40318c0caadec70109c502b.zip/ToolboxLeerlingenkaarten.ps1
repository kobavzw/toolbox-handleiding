$strURL = "https://toolbox.be/public/api/v1/leerlingenkaarten/"
$filePath=""

$username = "leerlingenkaarten"
$password = "VRAAG-DIT-AAN-TOOLBOX-HELPDESK"

$fileName=$filePath+"leerlingenkaarten.json"


$base64AuthInfo = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(("{0}:{1}" -f $username,$password)))


Invoke-RestMethod -Uri $strURL -Headers @{Authorization=("Basic {0}" -f $base64AuthInfo)} -Method GET -OutFile $fileName